# Tic-Tac-Toe
Repository for a [Dev.to article](https://dev.to/bornasepic/pure-and-simple-tic-tac-toe-with-javascript-4pgn)

#### Typescript
If you're interested in a type supported version of the game checkout the `typescript` branch and follow the instructions from there.

